#!/usr/bin/env python3
"""Open MSV000101183 outcomes once and execute the immutable v1 runner."""

from __future__ import annotations

from collections import Counter
import csv
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time


ROOT = Path(__file__).resolve().parents[1]
LOCK_NAME = "MSV000101183_v1"
ACCESSION = "MSV000101183"
LOCK_ROOT = ROOT / "prospective" / "locks" / LOCK_NAME
FROZEN_DIR = LOCK_ROOT / "frozen"
INBOX_DIR = LOCK_ROOT / "inbox"
RESULT_DIR = LOCK_ROOT / "results"
PREP_DIR = LOCK_ROOT / "preprocessing"
PRELABEL_DIR = PREP_DIR / "prelabel_freeze"
TIMESTAMP_DIR = LOCK_ROOT / "public_timestamp"
SEALED_METADATA = PREP_DIR / "sealed_metadata" / "meta.csv"
RUN_MAP = PREP_DIR / "work" / "run_map_blinded.csv"
RUNNER = ROOT / "scripts" / "14_run_msv000101183_validation.R"


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def write_json_atomic(path: Path, value: dict[str, object]) -> None:
    temporary = path.with_suffix(path.suffix + ".part")
    with temporary.open("w", encoding="utf-8") as handle:
        json.dump(value, handle, indent=2, sort_keys=True)
        handle.write("\n")
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(temporary, path)


def write_csv_atomic(path: Path, rows: list[dict[str, str]]) -> None:
    temporary = path.with_suffix(path.suffix + ".part")
    with temporary.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=["sample_id", "condition"])
        writer.writeheader()
        writer.writerows(rows)
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(temporary, path)


def verify_timestamp(stem: str) -> None:
    data_path = TIMESTAMP_DIR / f"{stem}.txt"
    response_path = TIMESTAMP_DIR / f"{stem}.digicert.tsr"
    cert_path = TIMESTAMP_DIR / f"{stem}.digicert.certs.pem"
    if not all(path.exists() for path in (data_path, response_path, cert_path)):
        raise RuntimeError(f"Missing RFC 3161 artifacts for {stem}.")
    result = subprocess.run(
        [
            "openssl",
            "ts",
            "-verify",
            "-data",
            str(data_path),
            "-in",
            str(response_path),
            "-CAfile",
            "/etc/ssl/cert.pem",
            "-untrusted",
            str(cert_path),
        ],
        capture_output=True,
        text=True,
        check=False,
    )
    if result.returncode != 0 or "Verification: OK" not in result.stdout:
        raise RuntimeError(f"RFC 3161 verification failed for {stem}.")


def verify_manifest(manifest_path: Path, expected_id_path: Path) -> str:
    expected_id = expected_id_path.read_text(encoding="utf-8").strip()
    with manifest_path.open(newline="", encoding="utf-8") as handle:
        rows = list(csv.DictReader(handle))
    payload: list[str] = []
    for row in rows:
        path = ROOT / row["path"]
        if not path.exists() or path.stat().st_size != int(row["bytes"]):
            raise RuntimeError("A committed artifact is missing or changed in size.")
        if sha256_file(path) != row["sha256"]:
            raise RuntimeError("A committed artifact hash changed.")
        payload.append(f'{row["path"]}\t{row["bytes"]}\t{row["sha256"]}')
    observed_id = hashlib.sha256("\n".join(payload).encode("utf-8")).hexdigest()
    if observed_id != expected_id:
        raise RuntimeError("Manifest commitment ID verification failed.")
    return expected_id


def normalize_label(value: str) -> str:
    return re.sub(r"\s+", " ", re.sub(r"[^a-z0-9]+", " ", value.lower())).strip()


def load_dictionary() -> dict[str, str]:
    path = LOCK_ROOT / "OUTCOME_DICTIONARY.tsv"
    with path.open(newline="", encoding="utf-8") as handle:
        rows = list(csv.DictReader(handle, delimiter="\t"))
    mapping: dict[str, str] = {}
    for row in rows:
        key = row["normalized_source_term"]
        canonical = row["canonical_condition"]
        if key in mapping and mapping[key] != canonical:
            raise RuntimeError("The locked outcome dictionary is ambiguous.")
        mapping[key] = canonical
    return mapping


def load_expected_counts() -> dict[str, int]:
    path = LOCK_ROOT / "AGGREGATE_CONDITION_TABLE.tsv"
    with path.open(newline="", encoding="utf-8") as handle:
        rows = list(csv.DictReader(handle, delimiter="\t"))
    counts = {row["canonical_condition"]: int(row["expected_n"]) for row in rows}
    if counts != {"Healthy": 20, "IPMC": 4, "PDAC": 16}:
        raise RuntimeError("The locked aggregate table failed its invariant.")
    return counts


def load_run_map() -> dict[str, str]:
    with RUN_MAP.open(newline="", encoding="utf-8") as handle:
        rows = list(csv.DictReader(handle))
    mapping = {row["raw_file"]: row["sample_id"] for row in rows}
    if len(mapping) != 40 or set(mapping) != {f"{index}.raw" for index in range(1, 41)}:
        raise RuntimeError("The blinded run map failed its invariant.")
    return mapping


def parse_metadata_once() -> tuple[list[dict[str, str]], dict[str, int], list[str]]:
    dictionary = load_dictionary()
    expected_counts = load_expected_counts()
    run_map = load_run_map()
    rows: list[dict[str, str]] = []
    unknown: list[str] = []
    seen_files: set[str] = set()
    with SEALED_METADATA.open(newline="", encoding="utf-8-sig") as handle:
        reader = csv.DictReader(handle)
        if reader.fieldnames != ["No.", "Raw files", "Groups"]:
            return [], {}, ["<HEADER_MISMATCH>"]
        for source in reader:
            raw_file = source["Raw files"].strip().replace("\\", "/").rsplit("/", 1)[-1]
            if raw_file.isdigit():
                raw_file += ".raw"
            normalized = normalize_label(source["Groups"])
            canonical = dictionary.get(normalized)
            if canonical is None:
                unknown.append(normalized or "<EMPTY>")
                continue
            if raw_file not in run_map or raw_file in seen_files:
                unknown.append("<RAW_FILE_STRUCTURE_MISMATCH>")
                continue
            seen_files.add(raw_file)
            rows.append({"sample_id": run_map[raw_file], "condition": canonical})
    observed = dict(Counter(row["condition"] for row in rows))
    if len(rows) != 40 or seen_files != set(run_map) or observed != expected_counts:
        unknown.append("<AGGREGATE_OR_ROW_COUNT_MISMATCH>")
    rows.sort(key=lambda row: row["sample_id"])
    return rows, observed, sorted(set(unknown))


def preflight(lock_id: str, prelabel_id: str) -> None:
    required = [
        SEALED_METADATA,
        RUN_MAP,
        RUNNER,
        INBOX_DIR / "abundance.csv",
        PRELABEL_DIR / "assay_eligibility.csv",
        PRELABEL_DIR / "frozen_panels_prelabel.csv",
    ]
    if not all(path.exists() for path in required):
        raise RuntimeError("One-shot inputs are incomplete.")
    if (INBOX_DIR / "metadata.csv").exists():
        raise RuntimeError("metadata.csv already exists; outcome access may have started.")
    if (RESULT_DIR / "ONE_SHOT_STARTED.json").exists() or (RESULT_DIR / "decision.json").exists():
        raise RuntimeError("One-shot outcome access has already started.")
    with (INBOX_DIR / "abundance.csv").open(newline="", encoding="utf-8") as handle:
        header = next(csv.reader(handle))
    if not header or header[0] != "feature" or len(header) != 41 or len(set(header[1:])) != 40:
        raise RuntimeError("The abundance matrix lacks 40 unique blinded samples.")

    lock_disclosure = (TIMESTAMP_DIR / "LOCK_DISCLOSURE.txt").read_text(encoding="utf-8")
    prelabel_disclosure = (TIMESTAMP_DIR / "PRELABEL_DISCLOSURE.txt").read_text(encoding="utf-8")
    if lock_id not in lock_disclosure or lock_id not in prelabel_disclosure:
        raise RuntimeError("Timestamp disclosures do not bind the active lock.")
    if prelabel_id not in prelabel_disclosure:
        raise RuntimeError("Prelabel disclosure does not bind the active prelabel ID.")
    if sha256_file(PRELABEL_DIR / "prelabel_manifest_sha256.csv") not in prelabel_disclosure:
        raise RuntimeError("Prelabel disclosure does not bind the active manifest hash.")

    with (FROZEN_DIR / "lock_manifest_sha256.csv").open(
        newline="", encoding="utf-8"
    ) as handle:
        runner_rows = [
            row
            for row in csv.DictReader(handle)
            if row["path"] == "scripts/14_run_msv000101183_validation.R"
        ]
    if len(runner_rows) != 1 or sha256_file(RUNNER) != runner_rows[0]["sha256"]:
        raise RuntimeError("The immutable runner failed verification.")

    dependency_check = subprocess.run(
        [
            "Rscript",
            "-e",
            "stopifnot(all(vapply(c('data.table','digest','jsonlite','limma'), requireNamespace, logical(1), quietly=TRUE)))",
        ],
        cwd=ROOT,
        check=False,
    )
    if dependency_check.returncode != 0:
        raise RuntimeError("Locked-runner R dependency preflight failed.")


def write_terminal_inconclusive(
    started: dict[str, object], observed: dict[str, int], issues: list[str]
) -> None:
    expected = load_expected_counts()
    decision = {
        "accession": ACCESSION,
        "lock_id": started["lock_id"],
        "status": "INCONCLUSIVE",
        "reason": "OUTCOME_SCHEMA_OR_COUNT_MISMATCH",
        "expected_counts": expected,
        "observed_counts": observed,
        "mapping_issues": issues,
        "statistical_runner_entered": False,
        "interpretation_ceiling": (
            "No performance estimate was produced because the timestamped "
            "outcome dictionary or aggregate count gate failed."
        ),
    }
    decision_path = RESULT_DIR / "decision.json"
    write_json_atomic(decision_path, decision)
    terminal = {
        **started,
        "event": "one-shot outcome access completed terminally",
        "completed_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "decision_sha256": sha256_file(decision_path),
        "status": "INCONCLUSIVE",
    }
    write_json_atomic(RESULT_DIR / "ONE_SHOT_COMPLETED.json", terminal)
    (RESULT_DIR / "RESULT.md").write_text(
        "# MSV000101183 locked validation result\n\n"
        "- Decision: INCONCLUSIVE\n"
        "- Reason: OUTCOME_SCHEMA_OR_COUNT_MISMATCH\n"
        "- Statistical runner entered: FALSE\n",
        encoding="utf-8",
    )


def main() -> None:
    RESULT_DIR.mkdir(parents=True, exist_ok=True)
    verify_timestamp("LOCK_DISCLOSURE")
    verify_timestamp("PRELABEL_DISCLOSURE")
    lock_id = verify_manifest(
        FROZEN_DIR / "lock_manifest_sha256.csv", FROZEN_DIR / "LOCK_ID.txt"
    )
    prelabel_id = verify_manifest(
        PRELABEL_DIR / "prelabel_manifest_sha256.csv", PRELABEL_DIR / "PRELABEL_ID.txt"
    )
    preflight(lock_id, prelabel_id)

    started = {
        "accession": ACCESSION,
        "event": "one-shot outcome access started",
        "lock_id": lock_id,
        "prelabel_id": prelabel_id,
        "sealed_metadata_sha256": sha256_file(SEALED_METADATA),
        "started_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
    }
    write_json_atomic(RESULT_DIR / "ONE_SHOT_STARTED.json", started)

    try:
        rows, observed, issues = parse_metadata_once()
        if issues:
            write_terminal_inconclusive(started, observed, issues)
            print("One-shot locked decision: INCONCLUSIVE")
            return
        metadata_path = INBOX_DIR / "metadata.csv"
        write_csv_atomic(metadata_path, rows)
        env = os.environ.copy()
        env["STAGEBRIDGE_UNLOCK_TOKEN"] = lock_id
        env["LC_ALL"] = "en_US.UTF-8"
        env["LANG"] = "en_US.UTF-8"
        result = subprocess.run(["Rscript", str(RUNNER)], cwd=ROOT, env=env, check=False)
        if result.returncode != 0:
            raise RuntimeError("The immutable locked runner exited unsuccessfully.")
        decision_path = RESULT_DIR / "decision.json"
        if not decision_path.exists():
            raise RuntimeError("The immutable runner did not write decision.json.")
        decision = json.loads(decision_path.read_text(encoding="utf-8"))
        if decision.get("status") not in {"PASS", "FAIL", "INCONCLUSIVE"}:
            raise RuntimeError("The immutable runner wrote an invalid decision status.")
        completed = {
            **started,
            "event": "one-shot outcome access completed",
            "completed_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            "metadata_sha256": sha256_file(metadata_path),
            "decision_sha256": sha256_file(decision_path),
            "status": decision["status"],
        }
        write_json_atomic(RESULT_DIR / "ONE_SHOT_COMPLETED.json", completed)
        print(f"One-shot locked decision: {decision['status']}")
    except Exception as error:
        failure = {
            **started,
            "event": "one-shot outcome access failed technically",
            "failed_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            "error_type": type(error).__name__,
            "error": str(error),
        }
        write_json_atomic(RESULT_DIR / "ONE_SHOT_TECHNICAL_FAILURE.json", failure)
        raise


if __name__ == "__main__":
    try:
        main()
    except Exception as error:
        print(f"ERROR: {error}", file=sys.stderr)
        raise SystemExit(1)
