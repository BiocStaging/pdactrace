#!/usr/bin/env Rscript
source(file.path(dirname(grep("^--file=", commandArgs(FALSE), value = TRUE) |> sub("^--file=", "", x = _)), "common.R"))

required <- c("data.table", "digest", "jsonlite")
missing <- required[!vapply(required, requireNamespace, logical(1), quietly = TRUE)]
if (length(missing)) stop("Install required packages: ", paste(missing, collapse = ", "))

lock_name <- "MSV000101183_v1"
accession <- "MSV000101183"
lock_root <- sb_dir("prospective", "locks", lock_name)
frozen_dir <- sb_dir("prospective", "locks", lock_name, "frozen")
inbox_dir <- sb_dir("prospective", "locks", lock_name, "inbox")
result_dir <- sb_dir("prospective", "locks", lock_name, "results")
invisible(sb_dir("prospective", "locks", lock_name, "preprocessing", "downloads"))
invisible(sb_dir("prospective", "locks", lock_name, "preprocessing", "sealed_metadata"))
invisible(sb_dir("prospective", "locks", lock_name, "preprocessing", "work"))
invisible(sb_dir("prospective", "locks", lock_name, "preprocessing", "prelabel_freeze"))
invisible(sb_dir("prospective", "locks", lock_name, "public_timestamp"))

lock_id_path <- file.path(frozen_dir, "LOCK_ID.txt")
refreeze_token <- "I_UNDERSTAND_MSV000101183_REFREEZE_INVALIDATES_V1"
if (file.exists(lock_id_path) && Sys.getenv("STAGEBRIDGE_REFREEZE") != refreeze_token) {
  stop("MSV000101183_v1 already exists; refreezing is forbidden.", call. = FALSE)
}
if (length(list.files(inbox_dir, all.files = TRUE, no.. = TRUE)) ||
    length(list.files(result_dir, all.files = TRUE, no.. = TRUE))) {
  stop("The new lock requires empty inbox and result directories.", call. = FALSE)
}
sealed_metadata <- file.path(lock_root, "preprocessing", "sealed_metadata", "meta.csv")
if (file.exists(sealed_metadata)) {
  stop("Sample-level metadata is already present; a pre-outcome v1 lock cannot be created.", call. = FALSE)
}

# Reuse only discovery objects already protected by the earlier independent lock.
source_manifest_path <- sb_path("prospective", "frozen", "lock_manifest_sha256.csv")
source_manifest <- read.csv(source_manifest_path, check.names = FALSE, stringsAsFactors = FALSE)
source_check <- sb_verify_lock_manifest(source_manifest, STAGEBRIDGE_ROOT)
if (!all(source_check$status == "PASS")) {
  stop("The source PDAC discovery lock no longer verifies.", call. = FALSE)
}
source_lock_id <- trimws(readLines(sb_path("prospective", "frozen", "LOCK_ID.txt"), warn = FALSE)[[1L]])

frozen_scores <- read.csv(
  sb_path("prospective", "frozen", "pdac_frozen_score_table.csv"),
  check.names = FALSE,
  stringsAsFactors = FALSE
)
absolute_panels <- read.csv(
  sb_path("prospective", "frozen", "pdac_absolute_panels.csv"),
  check.names = FALSE,
  stringsAsFactors = FALSE
)
method_specification <- read.csv(
  sb_path("prospective", "frozen", "method_specification.csv"),
  check.names = FALSE,
  stringsAsFactors = FALSE
)
score_methods <- method_specification$method
if (nrow(frozen_scores) != 1356L || anyDuplicated(frozen_scores$feature) ||
    !all(score_methods %in% names(frozen_scores)) ||
    !all(is.finite(frozen_scores$frozen_direction)) ||
    !all(frozen_scores$target_relation == "concordant")) {
  stop("The source PDAC discovery objects failed isolation checks.", call. = FALSE)
}
pdac <- readRDS(sb_path("data", "processed", "pdac_stagebridge.rds"))
if (any(pdac$effects$cohort == accession)) {
  stop("MSV000101183 is present in the discovery effects and is not eligible.", call. = FALSE)
}

score_path <- file.path(frozen_dir, "pdac_frozen_score_table.csv")
panel_path <- file.path(frozen_dir, "pdac_absolute_panels.csv")
method_path <- file.path(frozen_dir, "method_specification.csv")
utils::write.csv(frozen_scores, score_path, row.names = FALSE, na = "")
utils::write.csv(absolute_panels, panel_path, row.names = FALSE, na = "")
utils::write.csv(method_specification, method_path, row.names = FALSE, na = "")

# Canonicalize the public 94-assay dictionary already downloaded without labels.
source_target_path <- sb_path(
  "prospective", "preprocessing", "PXD067770", "downloads", "PRM_targets.csv"
)
target_raw <- read.csv(
  source_target_path,
  skip = 1L,
  check.names = FALSE,
  stringsAsFactors = FALSE
)
target_raw <- target_raw[grepl("^[0-9]+$", trimws(target_raw[[1L]])), , drop = FALSE]
target_assays <- data.frame(
  target_number = as.integer(trimws(target_raw[[1L]])),
  feature = trimws(target_raw[[2L]]),
  accession = trimws(target_raw[[3L]]),
  peptide = trimws(target_raw[[4L]]),
  modification = trimws(target_raw[[5L]]),
  precursor_mz = as.numeric(trimws(target_raw[[6L]])),
  product_mz = as.numeric(trimws(target_raw[[7L]])),
  stringsAsFactors = FALSE
)
if (nrow(target_assays) != 94L || anyDuplicated(target_assays$target_number) ||
    anyDuplicated(target_assays$feature) || any(!nzchar(target_assays$peptide)) ||
    any(!is.finite(target_assays$precursor_mz)) || any(!is.finite(target_assays$product_mz))) {
  stop("The public PRM target dictionary is not the expected 94-assay table.", call. = FALSE)
}
target_path <- file.path(frozen_dir, "prm_target_assays.csv")
utils::write.csv(target_assays, target_path, row.names = FALSE, na = "")

decision_rule <- jsonlite::read_json(file.path(lock_root, "DECISION_RULE.json"), simplifyVector = TRUE)
expected_counts <- unlist(decision_rule$expected_counts)
if (!identical(as.integer(expected_counts[c("Healthy", "IPMC", "PDAC")]), c(20L, 4L, 16L))) {
  stop("DECISION_RULE expected counts differ from the public aggregate table.", call. = FALSE)
}

lock_metadata <- list(
  lock_name = lock_name,
  accession = accession,
  frozen_at_utc = format(Sys.time(), tz = "UTC", usetz = TRUE),
  protocol_class = "prospectively locked reanalysis of a retrospective public cohort",
  source_pdac_lock_id = source_lock_id,
  sample_level_outcome_opened_before_lock = FALSE,
  public_outcome_dictionary_known = TRUE,
  public_aggregate_counts_known = TRUE,
  expected_counts = list(Healthy = 20L, IPMC = 4L, PDAC = 16L),
  expected_biological_samples = 40L,
  expected_pooled_qc_files = 5L,
  candidate_universe = nrow(frozen_scores),
  prm_target_assays = nrow(target_assays),
  target_relation = "concordant",
  inverse_analysis_allowed = FALSE,
  primary_endpoint = "PDAC_vs_Healthy",
  ipmc_required_for_pass = FALSE,
  assay_eligibility = "finite in >=70% of biological samples and >=3/5 pooled QC files",
  bootstrap_replicates = 2000L,
  bootstrap_seed = 20260717L,
  published_validation_performance_used = FALSE,
  source_target_sha256 = digest::digest(
    source_target_path,
    algo = "sha256",
    serialize = FALSE,
    file = TRUE
  )
)
metadata_path <- file.path(frozen_dir, "lock_metadata.json")
jsonlite::write_json(lock_metadata, metadata_path, auto_unbox = TRUE, pretty = TRUE)

script_paths <- sb_path(
  "scripts",
  c(
    "13_freeze_msv000101183_protocol.R",
    "14_run_msv000101183_validation.R",
    "15_download_msv000101183_blinded.py",
    "16_extract_msv000101183_abundance.R",
    "17_freeze_msv000101183_prelabel.R",
    "18_open_msv000101183_once.py"
  )
)
protocol_paths <- file.path(
  lock_root,
  c(
    "README.md",
    "PUBLIC_EVIDENCE.md",
    "OUTCOME_DICTIONARY.tsv",
    "AGGREGATE_CONDITION_TABLE.tsv",
    "COHORT_MANIFEST.tsv",
    "PRELOCK_ACCESS_LOG.tsv",
    "DECISION_RULE.json",
    "INPUT_SCHEMA.md",
    "LOCKED_PROTOCOL.md"
  )
)
lock_paths <- c(
  list.files(sb_path("R"), pattern = "[.]R$", full.names = TRUE),
  sb_path("DESCRIPTION"),
  sb_path("NAMESPACE"),
  sb_path("scripts", "common.R"),
  script_paths,
  protocol_paths,
  score_path,
  panel_path,
  method_path,
  target_path,
  metadata_path
)
if (!all(file.exists(lock_paths))) {
  stop("One or more v1 lock artifacts are missing.", call. = FALSE)
}
manifest <- sb_lock_manifest(lock_paths, STAGEBRIDGE_ROOT)
manifest_path <- file.path(frozen_dir, "lock_manifest_sha256.csv")
utils::write.csv(manifest, manifest_path, row.names = FALSE, na = "")
payload <- paste(manifest$path, manifest$bytes, manifest$sha256, sep = "\t", collapse = "\n")
lock_id <- digest::digest(payload, algo = "sha256", serialize = FALSE)
writeLines(lock_id, lock_id_path)

verification <- sb_verify_lock_manifest(manifest_path, STAGEBRIDGE_ROOT)
if (!all(verification$status == "PASS")) {
  stop("MSV000101183_v1 lock verification failed.", call. = FALSE)
}
message(accession, " protocol frozen with lock ID ", lock_id)
