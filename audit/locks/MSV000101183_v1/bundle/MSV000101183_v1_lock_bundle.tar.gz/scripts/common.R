script_argument <- grep("^--file=", commandArgs(trailingOnly = FALSE), value = TRUE)
script_file <- if (length(script_argument)) sub("^--file=", "", script_argument[[1]]) else "scripts/common.R"
STAGEBRIDGE_ROOT <- normalizePath(file.path(dirname(script_file), ".."), mustWork = TRUE)

for (source_file in sort(list.files(file.path(STAGEBRIDGE_ROOT, "R"), pattern = "[.]R$", full.names = TRUE))) {
  source(source_file, local = globalenv())
}

sb_path <- function(...) file.path(STAGEBRIDGE_ROOT, ...)

sb_dir <- function(...) {
  path <- sb_path(...)
  dir.create(path, recursive = TRUE, showWarnings = FALSE)
  path
}

sb_write_csv <- function(x, ...) {
  path <- sb_path(...)
  dir.create(dirname(path), recursive = TRUE, showWarnings = FALSE)
  utils::write.csv(x, path, row.names = FALSE, na = "")
  message("Wrote ", path)
  invisible(path)
}

