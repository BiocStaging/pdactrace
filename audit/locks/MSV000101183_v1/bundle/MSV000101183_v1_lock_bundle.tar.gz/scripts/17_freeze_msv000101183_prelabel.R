#!/usr/bin/env Rscript
source(file.path(dirname(grep("^--file=", commandArgs(FALSE), value = TRUE) |> sub("^--file=", "", x = _)), "common.R"))

required <- c("digest", "jsonlite")
missing <- required[!vapply(required, requireNamespace, logical(1), quietly = TRUE)]
if (length(missing)) stop("Install required packages: ", paste(missing, collapse = ", "))

lock_name <- "MSV000101183_v1"
lock_root <- sb_path("prospective", "locks", lock_name)
frozen_dir <- file.path(lock_root, "frozen")
inbox_dir <- file.path(lock_root, "inbox")
prep_dir <- file.path(lock_root, "preprocessing")
work_dir <- file.path(prep_dir, "work")
prelabel_dir <- file.path(prep_dir, "prelabel_freeze")
timestamp_dir <- file.path(lock_root, "public_timestamp")
dir.create(prelabel_dir, recursive = TRUE, showWarnings = FALSE)

verify_timestamp <- function(stem) {
  disclosure <- file.path(timestamp_dir, paste0(stem, ".txt"))
  response <- file.path(timestamp_dir, paste0(stem, ".digicert.tsr"))
  certificates <- file.path(timestamp_dir, paste0(stem, ".digicert.certs.pem"))
  if (!all(file.exists(c(disclosure, response, certificates)))) {
    stop("Missing RFC 3161 artifacts for ", stem, ".", call. = FALSE)
  }
  output <- system2(
    "openssl",
    c(
      "ts", "-verify", "-data", disclosure, "-in", response,
      "-CAfile", "/etc/ssl/cert.pem", "-untrusted", certificates
    ),
    stdout = TRUE,
    stderr = TRUE
  )
  if (!identical(attr(output, "status"), NULL) ||
      !any(grepl("Verification: OK", output, fixed = TRUE))) {
    stop("External timestamp verification failed for ", stem, ".", call. = FALSE)
  }
}

verify_timestamp("LOCK_DISCLOSURE")
manifest_path <- file.path(frozen_dir, "lock_manifest_sha256.csv")
manifest <- read.csv(manifest_path, check.names = FALSE, stringsAsFactors = FALSE)
lock_check <- sb_verify_lock_manifest(manifest, STAGEBRIDGE_ROOT)
if (!all(lock_check$status == "PASS")) stop("The active lock failed verification.")
lock_id <- trimws(readLines(file.path(frozen_dir, "LOCK_ID.txt"), warn = FALSE)[[1L]])
if (!grepl(lock_id, paste(readLines(file.path(timestamp_dir, "LOCK_DISCLOSURE.txt")), collapse = "\n"), fixed = TRUE)) {
  stop("The external timestamp does not bind the active lock.", call. = FALSE)
}
if (file.exists(file.path(inbox_dir, "metadata.csv")) ||
    file.exists(file.path(lock_root, "results", "ONE_SHOT_STARTED.json"))) {
  stop("Outcome access has already started; prelabel refreezing is forbidden.", call. = FALSE)
}
prelabel_id_path <- file.path(prelabel_dir, "PRELABEL_ID.txt")
if (file.exists(prelabel_id_path)) {
  stop("A prelabel freeze already exists and may not be overwritten.", call. = FALSE)
}

abundance_path <- file.path(inbox_dir, "abundance.csv")
work_eligibility_path <- file.path(work_dir, "assay_eligibility.csv")
required_work <- c(
  abundance_path,
  work_eligibility_path,
  file.path(work_dir, "run_map_blinded.csv"),
  file.path(work_dir, "raw_download_manifest.csv"),
  file.path(work_dir, "blinded_extraction_record.json"),
  file.path(work_dir, "sealed_metadata_record.json"),
  file.path(prep_dir, "sealed_metadata", "meta.csv")
)
if (!all(file.exists(required_work))) stop("Label-blind preprocessing is incomplete.")

abundance_raw <- read.csv(abundance_path, check.names = FALSE, stringsAsFactors = FALSE)
sample_ids <- setdiff(names(abundance_raw), "feature")
if (!identical(names(abundance_raw)[[1L]], "feature") || length(sample_ids) != 40L ||
    anyDuplicated(sample_ids) || anyDuplicated(abundance_raw$feature)) {
  stop("The abundance matrix does not contain 40 unique blinded samples.", call. = FALSE)
}
abundance <- as.matrix(abundance_raw[, sample_ids, drop = FALSE])
storage.mode(abundance) <- "double"
rownames(abundance) <- abundance_raw$feature

rule <- jsonlite::read_json(file.path(lock_root, "DECISION_RULE.json"), simplifyVector = TRUE)
eligibility <- read.csv(work_eligibility_path, check.names = FALSE, stringsAsFactors = FALSE)
if (anyDuplicated(eligibility$feature) || !setequal(eligibility$feature, rownames(abundance))) {
  stop("Eligibility rows do not match abundance features.", call. = FALSE)
}
eligibility <- eligibility[match(rownames(abundance), eligibility$feature), ]
observed_completeness <- rowMeans(is.finite(abundance))
expected_eligible <- observed_completeness >= rule$assay_completeness_fraction &
  eligibility$pooled_qc_detections >= rule$minimum_pooled_qc_detections
if (any(abs(observed_completeness - eligibility$biological_completeness) > 1e-12) ||
    !all(as.logical(eligibility$assay_eligible) == unname(expected_eligible))) {
  stop("The extraction eligibility table differs from the frozen rule.", call. = FALSE)
}
eligibility_path <- file.path(prelabel_dir, "assay_eligibility.csv")
utils::write.csv(eligibility, eligibility_path, row.names = FALSE, na = "")

frozen_scores <- read.csv(
  file.path(frozen_dir, "pdac_frozen_score_table.csv"),
  check.names = FALSE,
  stringsAsFactors = FALSE
)
method_specification <- read.csv(
  file.path(frozen_dir, "method_specification.csv"),
  check.names = FALSE,
  stringsAsFactors = FALSE
)
score_methods <- method_specification$method
eligible_scores <- frozen_scores[
  frozen_scores$feature %in% eligibility$feature[eligibility$assay_eligible] &
    is.finite(frozen_scores$frozen_direction),
]
if (!nrow(eligible_scores)) stop("No frozen candidate is assay eligible.", call. = FALSE)

panel_rows <- list()
panel_index <- 0L
for (method in score_methods) {
  ordered <- eligible_scores[order(-eligible_scores[[method]], eligible_scores$feature, na.last = NA), ]
  for (k in c(5L, 10L, 20L)) {
    selected <- head(ordered, min(k, nrow(ordered)))
    if (!nrow(selected)) next
    panel_index <- panel_index + 1L
    panel_rows[[panel_index]] <- data.frame(
      method = method,
      requested_panel_size = k,
      selected_features = nrow(selected),
      panel_order = seq_len(nrow(selected)),
      feature = selected$feature,
      frozen_tissue_direction = selected$frozen_direction,
      effective_blood_direction = selected$frozen_direction,
      rank_weight = 1 / log2(seq_len(nrow(selected)) + 1),
      discovery_score = selected[[method]],
      target_relation = "concordant",
      stringsAsFactors = FALSE
    )
  }
}
panels <- do.call(rbind, panel_rows)
panel_path <- file.path(prelabel_dir, "frozen_panels_prelabel.csv")
utils::write.csv(panels, panel_path, row.names = FALSE, na = "")

prelabel_paths <- c(
  abundance_path,
  eligibility_path,
  panel_path,
  file.path(work_dir, "run_map_blinded.csv"),
  file.path(work_dir, "raw_download_manifest.csv"),
  file.path(work_dir, "blinded_extraction_record.json"),
  file.path(work_dir, "sealed_metadata_record.json"),
  file.path(prep_dir, "sealed_metadata", "meta.csv"),
  manifest_path,
  file.path(frozen_dir, "LOCK_ID.txt")
)
prelabel_manifest <- sb_lock_manifest(prelabel_paths, STAGEBRIDGE_ROOT)
prelabel_manifest_path <- file.path(prelabel_dir, "prelabel_manifest_sha256.csv")
utils::write.csv(prelabel_manifest, prelabel_manifest_path, row.names = FALSE, na = "")
payload <- paste(
  prelabel_manifest$path,
  prelabel_manifest$bytes,
  prelabel_manifest$sha256,
  sep = "\t",
  collapse = "\n"
)
prelabel_id <- digest::digest(payload, algo = "sha256", serialize = FALSE)
writeLines(prelabel_id, prelabel_id_path)

prelabel_check <- sb_verify_lock_manifest(prelabel_manifest_path, STAGEBRIDGE_ROOT)
if (!all(prelabel_check$status == "PASS")) stop("Prelabel manifest verification failed.")
manifest_sha256 <- digest::digest(
  prelabel_manifest_path,
  algo = "sha256",
  serialize = FALSE,
  file = TRUE
)
disclosure <- c(
  "StageBridge MSV000101183 v1 prelabel disclosure",
  "Disclosure version: 1",
  paste("Prepared UTC:", format(Sys.time(), tz = "UTC", usetz = TRUE)),
  "",
  paste("LOCK_ID:", lock_id),
  paste("PRELABEL_ID:", prelabel_id),
  paste("SHA-256 of prelabel_manifest_sha256.csv:", manifest_sha256),
  paste("Biological samples:", length(sample_ids)),
  paste("Frozen target assays:", nrow(eligibility)),
  paste("Eligible target assays:", sum(eligibility$assay_eligible)),
  "Sample-level outcome rows opened: FALSE",
  "",
  "This payload binds abundance, assay eligibility, assay-conditional panels,",
  "RAW hashes, extraction software identity and the still-sealed metadata bytes."
)
writeLines(disclosure, file.path(timestamp_dir, "PRELABEL_DISCLOSURE.txt"))
message("Prelabel artifacts frozen with PRELABEL_ID ", prelabel_id)
