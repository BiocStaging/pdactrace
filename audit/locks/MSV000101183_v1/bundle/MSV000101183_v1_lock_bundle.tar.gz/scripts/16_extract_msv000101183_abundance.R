#!/usr/bin/env Rscript
source(file.path(dirname(grep("^--file=", commandArgs(FALSE), value = TRUE) |> sub("^--file=", "", x = _)), "common.R"))

rawrr_lib <- Sys.getenv("STAGEBRIDGE_RAWRR_LIB", "/private/tmp/stagebridge-Rlib")
if (dir.exists(rawrr_lib)) .libPaths(c(rawrr_lib, .libPaths()))
required <- c("digest", "jsonlite", "rawrr")
missing <- required[!vapply(required, requireNamespace, logical(1), quietly = TRUE)]
if (length(missing)) stop("Install required packages: ", paste(missing, collapse = ", "))

lock_name <- "MSV000101183_v1"
accession <- "MSV000101183"
lock_root <- sb_path("prospective", "locks", lock_name)
frozen_dir <- file.path(lock_root, "frozen")
prep_dir <- file.path(lock_root, "preprocessing")
download_dir <- file.path(prep_dir, "downloads")
work_dir <- file.path(prep_dir, "work")
checkpoint_dir <- file.path(work_dir, "peak_area")
timestamp_dir <- file.path(lock_root, "public_timestamp")
dir.create(checkpoint_dir, recursive = TRUE, showWarnings = FALSE)

verify_timestamp <- function(stem) {
  disclosure <- file.path(timestamp_dir, paste0(stem, ".txt"))
  response <- file.path(timestamp_dir, paste0(stem, ".digicert.tsr"))
  certificates <- file.path(timestamp_dir, paste0(stem, ".digicert.certs.pem"))
  if (!all(file.exists(c(disclosure, response, certificates)))) {
    stop("Missing external timestamp artifacts for ", stem, ".", call. = FALSE)
  }
  output <- system2(
    "openssl",
    c(
      "ts", "-verify", "-data", disclosure, "-in", response,
      "-CAfile", "/etc/ssl/cert.pem", "-untrusted", certificates
    ),
    stdout = TRUE,
    stderr = TRUE
  )
  if (!identical(attr(output, "status"), NULL) ||
      !any(grepl("Verification: OK", output, fixed = TRUE))) {
    stop("External timestamp verification failed for ", stem, ".", call. = FALSE)
  }
}

verify_timestamp("LOCK_DISCLOSURE")
lock_id <- trimws(readLines(file.path(frozen_dir, "LOCK_ID.txt"), warn = FALSE)[[1L]])
manifest <- read.csv(
  file.path(frozen_dir, "lock_manifest_sha256.csv"),
  check.names = FALSE,
  stringsAsFactors = FALSE
)
lock_check <- sb_verify_lock_manifest(manifest, STAGEBRIDGE_ROOT)
if (!all(lock_check$status == "PASS")) stop("The MSV000101183_v1 lock failed verification.")
if (!grepl(lock_id, paste(readLines(file.path(timestamp_dir, "LOCK_DISCLOSURE.txt")), collapse = "\n"), fixed = TRUE)) {
  stop("The timestamp does not bind the active LOCK_ID.", call. = FALSE)
}

run_map <- read.csv(
  file.path(work_dir, "run_map_blinded.csv"),
  check.names = FALSE,
  stringsAsFactors = FALSE
)
raw_manifest <- read.csv(
  file.path(work_dir, "raw_download_manifest.csv"),
  check.names = FALSE,
  stringsAsFactors = FALSE
)
expected_biological <- paste0(seq_len(40L), ".raw")
expected_qc <- paste0("acc_pooled", seq_len(5L), ".raw")
if (nrow(run_map) != 40L || anyDuplicated(run_map$sample_id) ||
    !setequal(run_map$raw_file, expected_biological) ||
    !setequal(raw_manifest$file_name, c(expected_biological, expected_qc))) {
  stop("The label-blind run map or RAW manifest differs from the lock.", call. = FALSE)
}
raw_paths <- file.path(download_dir, raw_manifest$file_name)
if (!all(file.exists(raw_paths)) ||
    !all(unname(file.info(raw_paths)$size) == raw_manifest$expected_bytes)) {
  stop("RAW files are missing or fail byte-count verification.", call. = FALSE)
}
observed_hash <- vapply(raw_paths, function(path) {
  digest::digest(path, algo = "sha256", serialize = FALSE, file = TRUE)
}, character(1))
if (!identical(unname(observed_hash), raw_manifest$sha256)) {
  stop("RAW hashes differ from the label-blind download manifest.", call. = FALSE)
}

targets <- read.csv(
  file.path(frozen_dir, "prm_target_assays.csv"),
  check.names = FALSE,
  stringsAsFactors = FALSE
)
if (nrow(targets) != 94L || anyDuplicated(targets$feature) ||
    any(!is.finite(targets$precursor_mz)) || any(!is.finite(targets$product_mz))) {
  stop("The frozen PRM assay dictionary failed verification.", call. = FALSE)
}

trapezoid_area <- function(time_minutes, intensity) {
  keep <- is.finite(time_minutes) & is.finite(intensity)
  time_minutes <- time_minutes[keep]
  intensity <- intensity[keep]
  if (length(time_minutes) < 3L) return(NA_real_)
  ordering <- order(time_minutes)
  seconds <- time_minutes[ordering] * 60
  intensity <- intensity[ordering]
  baseline <- unname(stats::quantile(intensity, 0.10, names = FALSE, type = 8))
  corrected <- pmax(intensity - baseline, 0)
  area <- sum(diff(seconds) * (head(corrected, -1L) + tail(corrected, -1L)) / 2)
  if (is.finite(area) && area > 0) area else NA_real_
}

match_target <- function(index, precursor_mz) {
  valid <- is.finite(index$precursorMass) & !is.na(index$scanType)
  candidate <- index[valid, , drop = FALSE]
  if (!nrow(candidate)) return(NULL)
  masses <- sort(unique(candidate$precursorMass))
  delta <- abs(masses - precursor_mz)
  if (min(delta) > 0.11) return(NULL)
  observed <- masses[which.min(delta)]
  rows <- candidate[abs(candidate$precursorMass - observed) < 1e-6, , drop = FALSE]
  scan_counts <- sort(table(rows$scanType), decreasing = TRUE)
  list(
    observed_precursor_mz = observed,
    precursor_delta = abs(observed - precursor_mz),
    scan_filter = names(scan_counts)[[1L]],
    scan_count = unname(scan_counts[[1L]])
  )
}

extract_target <- function(raw_path, mapping, product_mz) {
  tolerance_ppm <- 0.5 / product_mz * 1e6
  chromatogram <- rawrr::readChromatogram(
    rawfile = raw_path,
    mass = product_mz,
    tol = tolerance_ppm,
    type = "xic",
    filter = mapping$scan_filter
  )[[1L]]
  intensity <- chromatogram$intensities
  data.frame(
    observed_precursor_mz = mapping$observed_precursor_mz,
    precursor_delta = mapping$precursor_delta,
    scan_filter = mapping$scan_filter,
    scan_count = mapping$scan_count,
    trace_points = length(intensity),
    positive_trace_points = sum(is.finite(intensity) & intensity > 0),
    apex_intensity = if (any(is.finite(intensity))) max(intensity, na.rm = TRUE) else NA_real_,
    peak_area = trapezoid_area(chromatogram$times, intensity),
    stringsAsFactors = FALSE
  )
}

extract_run <- function(file_name, run_id, run_type) {
  checkpoint <- file.path(checkpoint_dir, paste0(run_id, ".csv"))
  if (file.exists(checkpoint)) {
    cached <- read.csv(checkpoint, check.names = FALSE, stringsAsFactors = FALSE)
    if (nrow(cached) == nrow(targets) && identical(cached$feature, targets$feature)) {
      return(checkpoint)
    }
  }
  raw_path <- file.path(download_dir, file_name)
  index <- rawrr::readIndex(raw_path)
  output <- targets
  output$run_id <- run_id
  output$run_type <- run_type
  output$raw_file <- file_name
  output$observed_precursor_mz <- NA_real_
  output$precursor_delta <- NA_real_
  output$scan_filter <- NA_character_
  output$scan_count <- NA_integer_
  output$trace_points <- NA_integer_
  output$positive_trace_points <- NA_integer_
  output$apex_intensity <- NA_real_
  output$peak_area <- NA_real_
  for (target_index in seq_len(nrow(targets))) {
    mapping <- match_target(index, targets$precursor_mz[[target_index]])
    if (is.null(mapping)) next
    value <- extract_target(raw_path, mapping, targets$product_mz[[target_index]])
    columns <- names(value)
    output[target_index, columns] <- value[1L, columns]
  }
  utils::write.csv(output, checkpoint, row.names = FALSE, na = "")
  message("Extracted label-blind run ", run_id)
  checkpoint
}

biological_jobs <- data.frame(
  file_name = run_map$raw_file,
  run_id = run_map$sample_id,
  run_type = "biological",
  stringsAsFactors = FALSE
)
qc_jobs <- data.frame(
  file_name = expected_qc,
  run_id = sub("[.]raw$", "", expected_qc),
  run_type = "pooled_qc",
  stringsAsFactors = FALSE
)
jobs <- rbind(biological_jobs, qc_jobs)
workers <- suppressWarnings(as.integer(Sys.getenv("STAGEBRIDGE_EXTRACTION_WORKERS", "4")))
if (!is.finite(workers) || workers < 1L) workers <- 1L
extract_job <- function(index) {
  extract_run(jobs$file_name[[index]], jobs$run_id[[index]], jobs$run_type[[index]])
}
checkpoint_paths <- if (.Platform$OS.type == "unix" && workers > 1L) {
  unlist(parallel::mclapply(seq_len(nrow(jobs)), extract_job, mc.cores = workers), use.names = FALSE)
} else {
  vapply(seq_len(nrow(jobs)), extract_job, character(1))
}
peak_rows <- do.call(rbind, lapply(checkpoint_paths, function(path) {
  read.csv(path, check.names = FALSE, stringsAsFactors = FALSE)
}))
if (nrow(peak_rows) != nrow(jobs) * nrow(targets) ||
    any(table(peak_rows$run_id) != nrow(targets))) {
  stop("Peak-area checkpoints do not form the expected 45 by 94 grid.", call. = FALSE)
}

biological_ids <- run_map$sample_id
area_matrix <- matrix(
  NA_real_,
  nrow = nrow(targets),
  ncol = length(biological_ids),
  dimnames = list(targets$feature, biological_ids)
)
for (sample_id in biological_ids) {
  values <- peak_rows[peak_rows$run_id == sample_id, ]
  area <- values$peak_area[match(targets$feature, values$feature)]
  area_matrix[, sample_id] <- ifelse(is.finite(area) & area > 0, log2(area), NA_real_)
}
qc_ids <- qc_jobs$run_id
qc_area <- matrix(
  NA_real_,
  nrow = nrow(targets),
  ncol = length(qc_ids),
  dimnames = list(targets$feature, qc_ids)
)
for (qc_id in qc_ids) {
  values <- peak_rows[peak_rows$run_id == qc_id, ]
  area <- values$peak_area[match(targets$feature, values$feature)]
  qc_area[, qc_id] <- ifelse(is.finite(area) & area > 0, area, NA_real_)
}
abundance <- data.frame(feature = rownames(area_matrix), area_matrix, check.names = FALSE)
abundance_path <- file.path(lock_root, "inbox", "abundance.csv")
dir.create(dirname(abundance_path), recursive = TRUE, showWarnings = FALSE)
utils::write.csv(abundance, abundance_path, row.names = FALSE, na = "")

biological_completeness <- rowMeans(is.finite(area_matrix))
pooled_qc_detections <- rowSums(is.finite(qc_area))
assay_eligible <- biological_completeness >= 0.70 & pooled_qc_detections >= 3L
eligibility <- data.frame(
  feature = targets$feature,
  mapped_biological_samples = vapply(targets$feature, function(feature) {
    sum(is.finite(peak_rows$observed_precursor_mz[
      peak_rows$feature == feature & peak_rows$run_type == "biological"
    ]))
  }, integer(1)),
  detected_biological_samples = rowSums(is.finite(area_matrix)),
  biological_completeness = biological_completeness,
  pooled_qc_detections = pooled_qc_detections,
  pooled_qc_cv = apply(qc_area, 1L, function(x) {
    x <- x[is.finite(x)]
    if (length(x) < 2L || mean(x) <= 0) NA_real_ else stats::sd(x) / mean(x)
  }),
  assay_eligible = assay_eligible,
  stringsAsFactors = FALSE
)
utils::write.csv(
  eligibility,
  file.path(work_dir, "assay_eligibility.csv"),
  row.names = FALSE,
  na = ""
)
utils::write.csv(
  peak_rows,
  file.path(work_dir, "blinded_peak_area_long.csv"),
  row.names = FALSE,
  na = ""
)

assembly_path <- rawrr:::rawrrAssemblyPath()
assembly_binary <- if (dir.exists(assembly_path)) file.path(assembly_path, "rawrr") else assembly_path
if (!file.exists(assembly_binary)) stop("The rawrr assembly binary is missing.")
extraction_record <- list(
  accession = accession,
  lock_id = lock_id,
  created_utc = format(Sys.time(), tz = "UTC", usetz = TRUE),
  clinical_metadata_read = FALSE,
  r_version = R.version.string,
  rawrr_package_version = as.character(utils::packageVersion("rawrr")),
  rawrr_assembly_version = rawrr:::.getRawrrAssemblyVersion(),
  rawrr_assembly_sha256 = digest::digest(
    assembly_binary,
    algo = "sha256",
    serialize = FALSE,
    file = TRUE
  ),
  biological_samples = ncol(area_matrix),
  pooled_qc_files = ncol(qc_area),
  target_assays = nrow(targets),
  eligible_target_assays = sum(assay_eligible),
  precursor_tolerance_da = 0.11,
  product_half_window_da = 0.5,
  baseline_quantile = 0.10,
  abundance_scale = "log2 baseline-subtracted trapezoidal product-ion peak area",
  eligibility_rule = "biological completeness >=0.70 and pooled-QC detection >=3/5",
  raw_manifest_sha256 = digest::digest(
    file.path(work_dir, "raw_download_manifest.csv"),
    algo = "sha256",
    serialize = FALSE,
    file = TRUE
  ),
  target_dictionary_sha256 = digest::digest(
    file.path(frozen_dir, "prm_target_assays.csv"),
    algo = "sha256",
    serialize = FALSE,
    file = TRUE
  ),
  abundance_sha256 = digest::digest(
    abundance_path,
    algo = "sha256",
    serialize = FALSE,
    file = TRUE
  )
)
jsonlite::write_json(
  extraction_record,
  file.path(work_dir, "blinded_extraction_record.json"),
  auto_unbox = TRUE,
  pretty = TRUE
)
message(
  "Wrote label-blind abundance for 40 samples and 94 targets; ",
  sum(assay_eligible), " targets pass the frozen eligibility rule."
)
