#!/usr/bin/env python3
"""Download MSV000101183 RAW data while keeping sample outcomes sealed."""

from __future__ import annotations

import csv
from concurrent.futures import ThreadPoolExecutor, as_completed
import hashlib
import json
import os
from pathlib import Path
import re
import ssl
import subprocess
import time
from urllib.error import HTTPError, URLError
from urllib.parse import quote
from urllib.request import Request, urlopen


ROOT = Path(__file__).resolve().parents[1]
LOCK_NAME = "MSV000101183_v1"
ACCESSION = "MSV000101183"
LOCK_ROOT = ROOT / "prospective" / "locks" / LOCK_NAME
FROZEN_DIR = LOCK_ROOT / "frozen"
TIMESTAMP_DIR = LOCK_ROOT / "public_timestamp"
PREP_DIR = LOCK_ROOT / "preprocessing"
DOWNLOAD_DIR = PREP_DIR / "downloads"
WORK_DIR = PREP_DIR / "work"
SEALED_DIR = PREP_DIR / "sealed_metadata"
TASK_ID = "6aab5886577844e098bea31f835c4954"
INVENTORY_URL = (
    "https://massive.ucsd.edu/ProteoSAFe/dataset_files.jsp?task=" + TASK_ID
)
DOWNLOAD_URL = "https://massive.ucsd.edu/ProteoSAFe/DownloadResultFile"


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def verify_timestamp(stem: str) -> None:
    data_path = TIMESTAMP_DIR / f"{stem}.txt"
    response_path = TIMESTAMP_DIR / f"{stem}.digicert.tsr"
    cert_path = TIMESTAMP_DIR / f"{stem}.digicert.certs.pem"
    if not all(path.exists() for path in (data_path, response_path, cert_path)):
        raise RuntimeError(f"Missing RFC 3161 artifacts for {stem}.")
    result = subprocess.run(
        [
            "openssl",
            "ts",
            "-verify",
            "-data",
            str(data_path),
            "-in",
            str(response_path),
            "-CAfile",
            "/etc/ssl/cert.pem",
            "-untrusted",
            str(cert_path),
        ],
        capture_output=True,
        text=True,
        check=False,
    )
    if result.returncode != 0 or "Verification: OK" not in result.stdout:
        raise RuntimeError(f"RFC 3161 verification failed for {stem}.")


def verify_lock() -> str:
    manifest_path = FROZEN_DIR / "lock_manifest_sha256.csv"
    lock_id = (FROZEN_DIR / "LOCK_ID.txt").read_text(encoding="utf-8").strip()
    with manifest_path.open(newline="", encoding="utf-8") as handle:
        rows = list(csv.DictReader(handle))
    payload: list[str] = []
    for row in rows:
        path = ROOT / row["path"]
        if not path.exists() or path.stat().st_size != int(row["bytes"]):
            raise RuntimeError("A locked artifact is missing or changed in size.")
        if sha256_file(path) != row["sha256"]:
            raise RuntimeError("A locked artifact hash changed.")
        payload.append(f'{row["path"]}\t{row["bytes"]}\t{row["sha256"]}')
    computed = hashlib.sha256("\n".join(payload).encode("utf-8")).hexdigest()
    if computed != lock_id:
        raise RuntimeError("LOCK_ID does not match the manifest.")
    if lock_id not in (TIMESTAMP_DIR / "LOCK_DISCLOSURE.txt").read_text(encoding="utf-8"):
        raise RuntimeError("Timestamp disclosure does not bind the active LOCK_ID.")
    return lock_id


def request_bytes(url: str, attempts: int = 10) -> bytes:
    context = ssl.create_default_context()
    last_error: Exception | None = None
    for attempt in range(attempts):
        try:
            request = Request(url, headers={"User-Agent": "StageBridge/0.1"})
            with urlopen(request, timeout=180, context=context) as response:
                return response.read()
        except (HTTPError, URLError, TimeoutError, ConnectionError) as error:
            last_error = error
            time.sleep(min(30, 2 ** min(attempt, 5)))
    raise RuntimeError("MassIVE request failed after repeated attempts.") from last_error


def inventory() -> tuple[list[dict[str, object]], dict[str, object]]:
    page = request_bytes(INVENTORY_URL).decode("utf-8", errors="strict")
    match = re.search(r"var dataset_files = (\{.*\});", page)
    if match is None:
        raise RuntimeError("Could not locate the MassIVE file inventory JSON.")
    value = json.loads(match.group(1))
    rows = value.get("row_data")
    if not isinstance(rows, list) or value.get("total_rows") != 93:
        raise RuntimeError("MassIVE inventory is not the frozen 93-file structure.")
    return rows, value


def sample_id(lock_id: str, raw_name: str) -> str:
    digest = hashlib.sha256(f"{lock_id}\t{raw_name}".encode("utf-8")).hexdigest()
    return "SB" + digest[:12].upper()


def download_url(descriptor: str) -> str:
    return f"{DOWNLOAD_URL}?file={quote(descriptor, safe='')}&forceDownload=true"


def download_one(row: dict[str, object], destination: Path) -> dict[str, object]:
    expected = int(row["size"])
    descriptor = str(row["file_descriptor"])
    part = destination.with_suffix(destination.suffix + ".part")
    if destination.exists() and destination.stat().st_size == expected:
        return {
            "file_name": destination.name,
            "file_descriptor": descriptor,
            "expected_bytes": expected,
            "local_bytes": expected,
            "sha256": sha256_file(destination),
            "retrieved_utc": "existing-byte-identical",
        }
    destination.unlink(missing_ok=True)
    part.unlink(missing_ok=True)
    payload = request_bytes(download_url(descriptor))
    if len(payload) != expected:
        raise RuntimeError(f"Byte count mismatch for {destination.name}.")
    with part.open("wb") as handle:
        handle.write(payload)
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(part, destination)
    return {
        "file_name": destination.name,
        "file_descriptor": descriptor,
        "expected_bytes": expected,
        "local_bytes": destination.stat().st_size,
        "sha256": sha256_file(destination),
        "retrieved_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
    }


def write_csv_atomic(path: Path, fieldnames: list[str], rows: list[dict[str, object]]) -> None:
    temporary = path.with_suffix(path.suffix + ".part")
    with temporary.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(temporary, path)


def main() -> None:
    verify_timestamp("LOCK_DISCLOSURE")
    lock_id = verify_lock()
    DOWNLOAD_DIR.mkdir(parents=True, exist_ok=True)
    WORK_DIR.mkdir(parents=True, exist_ok=True)
    SEALED_DIR.mkdir(parents=True, exist_ok=True)

    rows, summary = inventory()
    raw_rows = [row for row in rows if row.get("collection") == "raw"]
    metadata_rows = [
        row
        for row in rows
        if row.get("collection") == "metadata" and row.get("name") == "meta.csv"
    ]
    biological_names = {f"{index}.raw" for index in range(1, 41)}
    qc_names = {f"acc_pooled{index}.raw" for index in range(1, 6)}
    observed_names = {str(row["name"]) for row in raw_rows}
    if observed_names != biological_names | qc_names or len(metadata_rows) != 1:
        raise RuntimeError("MassIVE RAW or metadata structure differs from the lock.")

    run_map = [
        {
            "sample_id": sample_id(lock_id, name),
            "raw_file": name,
            "source_number": int(name.removesuffix(".raw")),
        }
        for name in biological_names
    ]
    run_map.sort(key=lambda row: int(row["source_number"]))
    write_csv_atomic(
        WORK_DIR / "run_map_blinded.csv",
        ["sample_id", "raw_file", "source_number"],
        run_map,
    )

    workers = max(1, min(12, int(os.getenv("STAGEBRIDGE_DOWNLOAD_WORKERS", "6"))))
    completed: list[dict[str, object]] = []
    with ThreadPoolExecutor(max_workers=workers) as executor:
        futures = {
            executor.submit(download_one, row, DOWNLOAD_DIR / str(row["name"])): row
            for row in raw_rows
        }
        for index, future in enumerate(as_completed(futures), start=1):
            completed.append(future.result())
            if index == 1 or index % 10 == 0 or index == len(futures):
                print(f"Verified {index}/{len(futures)} label-blind RAW files", flush=True)
    completed.sort(key=lambda row: str(row["file_name"]))
    write_csv_atomic(
        WORK_DIR / "raw_download_manifest.csv",
        [
            "file_name",
            "file_descriptor",
            "expected_bytes",
            "local_bytes",
            "sha256",
            "retrieved_utc",
        ],
        completed,
    )

    metadata_path = SEALED_DIR / "meta.csv"
    metadata_record = download_one(metadata_rows[0], metadata_path)
    sealed_record = {
        **metadata_record,
        "outcome_rows_parsed": False,
        "header_previously_checked": ["No.", "Raw files", "Groups"],
        "sealed_for_one_shot": True,
    }
    (WORK_DIR / "sealed_metadata_record.json").write_text(
        json.dumps(sealed_record, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    inventory_record = {
        "accession": ACCESSION,
        "task_id": TASK_ID,
        "total_repository_files": summary["total_rows"],
        "raw_files": len(raw_rows),
        "biological_raw_files": len(biological_names),
        "pooled_qc_raw_files": len(qc_names),
        "sample_level_outcome_opened": False,
        "created_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
    }
    (WORK_DIR / "label_blind_inventory.json").write_text(
        json.dumps(inventory_record, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    print("Label-blind download complete; metadata remains sealed.")


if __name__ == "__main__":
    main()
