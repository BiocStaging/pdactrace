#!/usr/bin/env Rscript
source(file.path(dirname(grep("^--file=", commandArgs(FALSE), value = TRUE) |> sub("^--file=", "", x = _)), "common.R"))

required <- c("data.table", "digest", "jsonlite", "limma")
missing <- required[!vapply(required, requireNamespace, logical(1), quietly = TRUE)]
if (length(missing)) stop("Install required packages: ", paste(missing, collapse = ", "))

lock_name <- "MSV000101183_v1"
accession <- "MSV000101183"
lock_root <- sb_path("prospective", "locks", lock_name)
frozen_dir <- file.path(lock_root, "frozen")
inbox_dir <- file.path(lock_root, "inbox")
prelabel_dir <- file.path(lock_root, "preprocessing", "prelabel_freeze")
out_dir <- file.path(lock_root, "results")
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)

manifest_path <- file.path(frozen_dir, "lock_manifest_sha256.csv")
lock_id_path <- file.path(frozen_dir, "LOCK_ID.txt")
manifest <- read.csv(manifest_path, check.names = FALSE, stringsAsFactors = FALSE)
verification <- sb_verify_lock_manifest(manifest, STAGEBRIDGE_ROOT)
if (!all(verification$status == "PASS")) {
  stop("Locked MSV000101183_v1 files changed after freeze.", call. = FALSE)
}
expected_token <- trimws(readLines(lock_id_path, warn = FALSE)[[1L]])
lock_payload <- paste(manifest$path, manifest$bytes, manifest$sha256, sep = "\t", collapse = "\n")
computed_token <- digest::digest(lock_payload, algo = "sha256", serialize = FALSE)
if (!identical(expected_token, computed_token)) stop("LOCK_ID verification failed.", call. = FALSE)
if (!identical(Sys.getenv("STAGEBRIDGE_UNLOCK_TOKEN"), expected_token)) {
  stop("Set STAGEBRIDGE_UNLOCK_TOKEN to the active LOCK_ID.", call. = FALSE)
}

decision_path <- file.path(out_dir, "decision.json")
if (file.exists(decision_path)) stop("A terminal decision already exists; overwrite is forbidden.", call. = FALSE)

prelabel_manifest_path <- file.path(prelabel_dir, "prelabel_manifest_sha256.csv")
if (!file.exists(prelabel_manifest_path)) stop("The prelabel manifest is missing.", call. = FALSE)
prelabel_manifest <- read.csv(prelabel_manifest_path, check.names = FALSE, stringsAsFactors = FALSE)
prelabel_check <- sb_verify_lock_manifest(prelabel_manifest, STAGEBRIDGE_ROOT)
if (!all(prelabel_check$status == "PASS")) {
  stop("A timestamp-bound prelabel artifact changed.", call. = FALSE)
}

rule <- jsonlite::read_json(file.path(lock_root, "DECISION_RULE.json"), simplifyVector = TRUE)
expected_counts <- as.integer(unlist(rule$expected_counts)[c("Healthy", "IPMC", "PDAC")])
names(expected_counts) <- c("Healthy", "IPMC", "PDAC")

write_result_csv <- function(x, filename) {
  path <- file.path(out_dir, filename)
  utils::write.csv(x, path, row.names = FALSE, na = "")
  invisible(path)
}

abundance_path <- file.path(inbox_dir, "abundance.csv")
metadata_path <- file.path(inbox_dir, "metadata.csv")
if (!file.exists(abundance_path) || !file.exists(metadata_path)) {
  stop("Both abundance.csv and one-shot metadata.csv are required.", call. = FALSE)
}
abundance_raw <- read.csv(abundance_path, check.names = FALSE, stringsAsFactors = FALSE)
if (!nrow(abundance_raw) || !identical(names(abundance_raw)[[1L]], "feature")) {
  stop("abundance.csv must begin with feature.", call. = FALSE)
}
feature <- trimws(abundance_raw$feature)
sample_ids <- setdiff(names(abundance_raw), "feature")
if (any(!nzchar(feature)) || anyDuplicated(feature) || length(sample_ids) != 40L ||
    anyDuplicated(sample_ids)) {
  stop("abundance.csv must contain unique features and exactly 40 blinded samples.", call. = FALSE)
}
abundance <- as.matrix(abundance_raw[, sample_ids, drop = FALSE])
storage.mode(abundance) <- "double"
rownames(abundance) <- feature

eligibility <- read.csv(
  file.path(prelabel_dir, "assay_eligibility.csv"),
  check.names = FALSE,
  stringsAsFactors = FALSE
)
required_eligibility <- c(
  "feature", "biological_completeness", "pooled_qc_detections", "assay_eligible"
)
if (!all(required_eligibility %in% names(eligibility)) || anyDuplicated(eligibility$feature) ||
    !setequal(eligibility$feature, rownames(abundance))) {
  stop("The prelabel assay eligibility table does not match abundance.csv.", call. = FALSE)
}
eligibility <- eligibility[match(rownames(abundance), eligibility$feature), ]
observed_completeness <- rowMeans(is.finite(abundance))
expected_eligible <- observed_completeness >= rule$assay_completeness_fraction &
  eligibility$pooled_qc_detections >= rule$minimum_pooled_qc_detections
if (any(abs(observed_completeness - eligibility$biological_completeness) > 1e-12) ||
    !all(as.logical(eligibility$assay_eligible) == unname(expected_eligible))) {
  stop("Assay eligibility differs from the timestamped abundance-only rule.", call. = FALSE)
}
eligible_features <- eligibility$feature[eligibility$assay_eligible]
if (!length(eligible_features)) stop("No assay passes the frozen eligibility rule.", call. = FALSE)

frozen_scores <- read.csv(
  file.path(frozen_dir, "pdac_frozen_score_table.csv"),
  check.names = FALSE,
  stringsAsFactors = FALSE
)
method_specification <- read.csv(
  file.path(frozen_dir, "method_specification.csv"),
  check.names = FALSE,
  stringsAsFactors = FALSE
)
score_methods <- method_specification$method
eligible_scores <- frozen_scores[
  frozen_scores$feature %in% eligible_features & is.finite(frozen_scores$frozen_direction),
]
if (!nrow(eligible_scores)) stop("No frozen candidate is assay eligible.", call. = FALSE)

panels <- read.csv(
  file.path(prelabel_dir, "frozen_panels_prelabel.csv"),
  check.names = FALSE,
  stringsAsFactors = FALSE
)
required_panel <- c(
  "method", "requested_panel_size", "selected_features", "panel_order", "feature",
  "frozen_tissue_direction", "effective_blood_direction", "rank_weight",
  "discovery_score", "target_relation"
)
if (!all(required_panel %in% names(panels)) ||
    any(!panels$feature %in% eligible_features) ||
    any(!panels$method %in% score_methods) ||
    any(panels$target_relation != "concordant")) {
  stop("The timestamped prelabel panels failed structural checks.", call. = FALSE)
}

robust_scale <- function(x) {
  observed <- x[is.finite(x)]
  if (!length(observed)) return(rep(0, length(x)))
  spread <- stats::sd(observed)
  if (!is.finite(spread) || spread <= 0) spread <- 1
  x[!is.finite(x)] <- min(observed) - 0.5 * spread
  center <- stats::median(x)
  scale <- stats::mad(x, center = center, constant = 1)
  if (!is.finite(scale) || scale <= 0) scale <- stats::sd(x)
  if (!is.finite(scale) || scale <= 0) return(rep(0, length(x)))
  pmax(-8, pmin(8, (x - center) / scale))
}
scaled <- t(apply(abundance[eligible_features, , drop = FALSE], 1L, robust_scale))
rownames(scaled) <- eligible_features
colnames(scaled) <- sample_ids

signature_rows <- list()
signature_index <- 0L
panel_groups <- split(panels, interaction(panels$method, panels$requested_panel_size, drop = TRUE))
for (panel in panel_groups) {
  panel <- panel[order(panel$panel_order), ]
  oriented <- scaled[panel$feature, , drop = FALSE] *
    (panel$effective_blood_direction * panel$rank_weight)
  patient_score <- colSums(oriented) / sum(panel$rank_weight)
  signature_index <- signature_index + 1L
  signature_rows[[signature_index]] <- data.frame(
    sample_id = names(patient_score),
    method = panel$method[[1L]],
    requested_panel_size = panel$requested_panel_size[[1L]],
    selected_features = nrow(panel),
    signature_score = unname(patient_score),
    stringsAsFactors = FALSE
  )
}
signature_scores <- do.call(rbind, signature_rows)

# Clinical labels enter here, after every abundance-only artifact has verified.
metadata <- read.csv(metadata_path, check.names = FALSE, stringsAsFactors = FALSE)
if (!all(c("sample_id", "condition") %in% names(metadata)) || nrow(metadata) != 40L ||
    anyDuplicated(metadata$sample_id) || !setequal(metadata$sample_id, sample_ids)) {
  stop("metadata.csv must map all 40 blinded samples exactly once.", call. = FALSE)
}
allowed_conditions <- names(expected_counts)
observed_counts <- table(factor(metadata$condition, levels = allowed_conditions))
schema_match <- setequal(unique(metadata$condition), allowed_conditions) &&
  identical(as.integer(observed_counts), unname(expected_counts))
if (!schema_match) {
  decision <- list(
    accession = accession,
    lock_id = expected_token,
    status = "INCONCLUSIVE",
    reason = "OUTCOME_SCHEMA_OR_COUNT_MISMATCH",
    expected_counts = as.list(expected_counts),
    observed_counts = as.list(as.integer(observed_counts)),
    observed_group_names = names(observed_counts),
    statistical_runner_entered = FALSE,
    interpretation_ceiling = "No performance estimate was produced because the public aggregate gate failed."
  )
  jsonlite::write_json(decision, decision_path, auto_unbox = TRUE, pretty = TRUE, null = "null")
  quit(save = "no", status = 0L)
}
metadata <- metadata[match(sample_ids, metadata$sample_id), ]
condition <- factor(metadata$condition, levels = c("Healthy", "IPMC", "PDAC"))

design <- stats::model.matrix(~ 0 + condition)
colnames(design) <- levels(condition)
contrast <- limma::makeContrasts(
  PDAC_vs_Healthy = PDAC - Healthy,
  IPMC_vs_Healthy = IPMC - Healthy,
  Invasive_vs_Healthy = 0.8 * PDAC + 0.2 * IPMC - Healthy,
  levels = design
)
fit <- suppressWarnings(limma::lmFit(abundance[eligible_features, sample_ids, drop = FALSE], design))
fit <- suppressWarnings(limma::eBayes(limma::contrasts.fit(fit, contrast), robust = TRUE))
differential <- data.frame(
  feature = rownames(fit$coefficients),
  logFC_PDAC_vs_Healthy = fit$coefficients[, "PDAC_vs_Healthy"],
  p_PDAC_vs_Healthy = fit$p.value[, "PDAC_vs_Healthy"],
  fdr_PDAC_vs_Healthy = stats::p.adjust(fit$p.value[, "PDAC_vs_Healthy"], method = "BH"),
  logFC_IPMC_vs_Healthy = fit$coefficients[, "IPMC_vs_Healthy"],
  p_IPMC_vs_Healthy = fit$p.value[, "IPMC_vs_Healthy"],
  fdr_IPMC_vs_Healthy = stats::p.adjust(fit$p.value[, "IPMC_vs_Healthy"], method = "BH"),
  logFC_Invasive_vs_Healthy = fit$coefficients[, "Invasive_vs_Healthy"],
  p_Invasive_vs_Healthy = fit$p.value[, "Invasive_vs_Healthy"],
  fdr_Invasive_vs_Healthy = stats::p.adjust(fit$p.value[, "Invasive_vs_Healthy"], method = "BH"),
  stringsAsFactors = FALSE
)
direction <- frozen_scores$frozen_direction[match(differential$feature, frozen_scores$feature)]
differential$frozen_tissue_direction <- direction
differential$primary_positive <-
  differential$fdr_PDAC_vs_Healthy < rule$feature_fdr_threshold &
  sign(differential$logFC_PDAC_vs_Healthy) == direction
differential$secondary_invasive_positive <-
  differential$fdr_Invasive_vs_Healthy < rule$feature_fdr_threshold &
  sign(differential$logFC_Invasive_vs_Healthy) == direction
write_result_csv(differential, "external_differential.csv")

feature_eval <- merge(
  differential,
  frozen_scores[, c("feature", score_methods), drop = FALSE],
  by = "feature",
  all.x = TRUE,
  sort = FALSE
)
feature_eval <- feature_eval[is.finite(feature_eval$StageBridge), ]
feature_truth <- feature_eval$primary_positive
feature_scores <- feature_eval[, c("feature", score_methods), drop = FALSE]
feature_metrics <- sb_evaluate_methods(
  feature_truth,
  feature_scores,
  top_k = min(20L, nrow(feature_eval))
)
feature_metrics_common <- sb_evaluate_common_methods(
  feature_truth,
  feature_scores,
  top_k = min(20L, nrow(feature_eval))
)
common_keep <- sb_common_method_rows(feature_truth, feature_scores)
write_result_csv(feature_eval, "feature_endpoint_table.csv")
write_result_csv(feature_eval[common_keep, ], "common_feature_universe.csv")
write_result_csv(feature_metrics, "feature_metrics.csv")
write_result_csv(feature_metrics_common, "feature_metrics_common.csv")

signature_scores$condition <- metadata$condition[match(signature_scores$sample_id, metadata$sample_id)]
bootstrap_metrics <- function(truth, score, seed, n_boot) {
  positive <- which(truth)
  negative <- which(!truth)
  if (!length(positive) || !length(negative)) {
    return(data.frame(
      auroc = NA_real_, auroc_low = NA_real_, auroc_high = NA_real_,
      auprc = NA_real_, auprc_low = NA_real_, auprc_high = NA_real_
    ))
  }
  set.seed(seed)
  values <- replicate(n_boot, {
    index <- c(
      sample(positive, length(positive), replace = TRUE),
      sample(negative, length(negative), replace = TRUE)
    )
    c(
      auroc = sb_binary_auc(truth[index], score[index]),
      auprc = sb_average_precision(truth[index], score[index])
    )
  })
  data.frame(
    auroc = sb_binary_auc(truth, score),
    auroc_low = unname(stats::quantile(values["auroc", ], 0.025)),
    auroc_high = unname(stats::quantile(values["auroc", ], 0.975)),
    auprc = sb_average_precision(truth, score),
    auprc_low = unname(stats::quantile(values["auprc", ], 0.025)),
    auprc_high = unname(stats::quantile(values["auprc", ], 0.975))
  )
}

endpoints <- list(
  PDAC_vs_Healthy = c("PDAC", "Healthy"),
  Invasive_vs_Healthy = c("PDAC", "IPMC", "Healthy"),
  IPMC_vs_Healthy = c("IPMC", "Healthy")
)
patient_rows <- list()
row_id <- 0L
for (endpoint_name in names(endpoints)) {
  endpoint_conditions <- endpoints[[endpoint_name]]
  for (method in score_methods) {
    for (k in c(5L, 10L, 20L)) {
      x <- signature_scores[
        signature_scores$condition %in% endpoint_conditions &
          signature_scores$method == method &
          signature_scores$requested_panel_size == k,
      ]
      truth <- if (endpoint_name == "Invasive_vs_Healthy") {
        x$condition %in% c("PDAC", "IPMC")
      } else {
        x$condition == sub("_vs_Healthy$", "", endpoint_name)
      }
      row_id <- row_id + 1L
      metric <- bootstrap_metrics(
        truth,
        x$signature_score,
        seed = rule$bootstrap_seed + row_id,
        n_boot = rule$bootstrap_replicates
      )
      patient_rows[[row_id]] <- cbind(
        data.frame(
          endpoint = endpoint_name,
          method = method,
          requested_panel_size = k,
          selected_features = unique(x$selected_features),
          n_case = sum(truth),
          n_reference = sum(!truth),
          stringsAsFactors = FALSE
        ),
        metric
      )
    }
  }
}
patient_metrics <- do.call(rbind, patient_rows)
write_result_csv(signature_scores, "patient_scores.csv")
write_result_csv(patient_metrics, "patient_metrics.csv")

stage_feature <- feature_metrics_common[feature_metrics_common$method == "StageBridge", ]
comparator_rows <- feature_metrics_common[
  feature_metrics_common$method != "StageBridge" & is.finite(feature_metrics_common$auprc),
]
best_comparator <- comparator_rows[order(-comparator_rows$auprc, comparator_rows$method), ][1L, ]
stage_primary <- patient_metrics[
  patient_metrics$endpoint == rule$primary_endpoint &
    patient_metrics$method == "StageBridge" &
    patient_metrics$requested_panel_size == rule$primary_panel_size,
]
stage_secondary <- patient_metrics[
  patient_metrics$endpoint == rule$secondary_endpoint &
    patient_metrics$method == "StageBridge" &
    patient_metrics$requested_panel_size == rule$primary_panel_size,
]
stage_ipmc <- patient_metrics[
  patient_metrics$endpoint == rule$descriptive_endpoint &
    patient_metrics$method == "StageBridge" &
    patient_metrics$requested_panel_size == rule$primary_panel_size,
]

enough_positives <- isTRUE(stage_feature$n_positive_common >= rule$minimum_common_positive_features)
enough_panel <- isTRUE(stage_primary$selected_features >= rule$minimum_primary_panel_features)
feature_margin <- isTRUE(
  stage_feature$auprc >= stage_feature$prevalence_common + rule$feature_average_precision_margin &&
    stage_feature$auprc >= best_comparator$auprc + rule$feature_average_precision_margin
)
primary_patient_pass <- isTRUE(
  stage_primary$auroc_low > rule$primary_patient_auroc_lower_bound_threshold
)
adequately_evaluable <- enough_positives && enough_panel
status <- if (!adequately_evaluable) {
  "INCONCLUSIVE"
} else if (feature_margin && primary_patient_pass) {
  "PASS"
} else {
  "FAIL"
}
reason <- if (!enough_positives) {
  "INSUFFICIENT_COMMON_POSITIVE_FEATURES"
} else if (!enough_panel) {
  "INSUFFICIENT_STAGEBRIDGE_PANEL_COVERAGE"
} else if (status == "PASS") {
  "ALL_PRIMARY_CRITERIA_MET"
} else {
  "ONE_OR_MORE_PRIMARY_PERFORMANCE_CRITERIA_MISSED"
}

decision <- list(
  accession = accession,
  lock_id = expected_token,
  status = status,
  reason = reason,
  target_relation = "concordant",
  expected_counts = as.list(expected_counts),
  observed_counts = as.list(as.integer(observed_counts)),
  observed_group_names = names(observed_counts),
  statistical_runner_entered = TRUE,
  common_features = stage_feature$n_common,
  common_positive_features = stage_feature$n_positive_common,
  stagebridge_feature_auprc = stage_feature$auprc,
  common_prevalence = stage_feature$prevalence_common,
  best_comparator = best_comparator$method,
  best_comparator_auprc = best_comparator$auprc,
  stagebridge_top10_selected = stage_primary$selected_features,
  primary_patient_auroc = stage_primary$auroc,
  primary_patient_auroc_low = stage_primary$auroc_low,
  secondary_invasive_auroc = stage_secondary$auroc,
  secondary_invasive_auroc_low = stage_secondary$auroc_low,
  descriptive_ipmc_auroc = stage_ipmc$auroc,
  descriptive_ipmc_auroc_low = stage_ipmc$auroc_low,
  criteria = list(
    exact_aggregate_match = TRUE,
    enough_common_positive_features = enough_positives,
    enough_primary_panel_features = enough_panel,
    feature_average_precision_margin = feature_margin,
    primary_patient_lower_ci_above_half = primary_patient_pass,
    ipmc_required_for_pass = FALSE
  ),
  interpretation_ceiling = paste(
    "A pass supports independent targeted-panel PDAC-versus-healthy serum transport only;",
    "it does not establish inflammatory specificity, clinical utility or cross-cancer generalization."
  )
)
jsonlite::write_json(decision, decision_path, auto_unbox = TRUE, pretty = TRUE, null = "null")

access_record <- data.frame(
  timestamp_utc = format(Sys.time(), tz = "UTC", usetz = TRUE),
  lock_id = expected_token,
  abundance_sha256 = digest::digest(abundance_path, algo = "sha256", serialize = FALSE, file = TRUE),
  metadata_sha256 = digest::digest(metadata_path, algo = "sha256", serialize = FALSE, file = TRUE),
  prelabel_manifest_sha256 = digest::digest(
    prelabel_manifest_path,
    algo = "sha256",
    serialize = FALSE,
    file = TRUE
  ),
  stringsAsFactors = FALSE
)
write_result_csv(access_record, "post_unlock_access_record.csv")

report <- c(
  "# MSV000101183 locked validation result",
  "",
  paste("- Lock ID:", expected_token),
  paste("- Decision:", status),
  paste("- Reason:", reason),
  paste("- Public/observed counts: Healthy 20, IPMC 4, PDAC 16"),
  paste("- Common universe:", stage_feature$n_common, "proteins;", stage_feature$n_positive_common, "positives"),
  paste0(
    "- StageBridge feature AP: ", formatC(stage_feature$auprc, digits = 3, format = "f"),
    "; best comparator (", best_comparator$method, "): ",
    formatC(best_comparator$auprc, digits = 3, format = "f")
  ),
  paste0(
    "- StageBridge top-10 PDAC-versus-Healthy AUROC: ",
    formatC(stage_primary$auroc, digits = 3, format = "f"), " (95% CI ",
    formatC(stage_primary$auroc_low, digits = 3, format = "f"), "-",
    formatC(stage_primary$auroc_high, digits = 3, format = "f"), ")"
  ),
  "",
  decision$interpretation_ceiling
)
writeLines(report, file.path(out_dir, "RESULT.md"))
message("Locked MSV000101183 validation completed with decision: ", status)
